package com.deliveryboy;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DeliveryboyappApplicationTests {

	@Test
	void contextLoads() {
	}

}
